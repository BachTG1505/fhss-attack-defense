"""
Task 4: TAN CONG GAUSSIAN NOISE
Them nhieu o 4 muc sigma khac nhau, do BER cho moi muc.
"""
import numpy as np
from scipy.io import wavfile
from embed_message import DELTA, K_REPEAT, MESSAGE, text_to_bits
from extract_baseline import extract_bits_from_audio, majority_vote_decode, compute_ber

SIGMA_LEVELS = [10, 50, 100, 200]


def main():
    fs, stego = wavfile.read('stego_audio.wav')
    if stego.ndim > 1:
        stego = stego[:, 0]
    stego = stego.astype(np.float64)

    original_bits = text_to_bits(MESSAGE)
    n_encoded = len(original_bits) * K_REPEAT

    results = []
    print("=" * 50)
    print("TASK 4: GAUSSIAN NOISE ATTACK")
    print("=" * 50)
    print(f"Config: DELTA = {DELTA}, K_REPEAT = {K_REPEAT}\n")
    print(f"{'sigma':>8} | {'BER':>8} | {'Status':<20}")
    print("-" * 50)

    for sigma in SIGMA_LEVELS:
        np.random.seed(123)
        noise = np.random.normal(0, sigma, stego.shape)
        attacked = np.clip(stego + noise, -32768, 32767).astype(np.int16)

        if sigma == 100:
            wavfile.write('attacked_audio.wav', fs, attacked)

        raw = extract_bits_from_audio(attacked, n_encoded)
        decoded = majority_vote_decode(raw, K_REPEAT)
        ber = compute_ber(original_bits, decoded)

        status = "ATTACK SUCCESS" if ber >= 20 else "PARTIAL"
        results.append((sigma, ber, status))
        print(f"{sigma:>8} | {ber:>7.2f}% | {status:<20}")

    with open('noise_report.txt', 'w') as f:
        f.write("Gaussian Noise BER Analysis\n")
        f.write("=" * 50 + "\n")
        f.write(f"Config: DELTA = {DELTA}, K_REPEAT = {K_REPEAT}\n\n")
        f.write(f"{'sigma':>8} | {'BER':>8} | {'Status':<20}\n")
        f.write("-" * 50 + "\n")
        for sigma, ber, status in results:
            f.write(f"{sigma:>8} | {ber:>7.2f}% | {status:<20}\n")

    print(f"\n[+] Hoan thanh 4 muc tan cong. Bao cao: noise_report.txt")


if __name__ == "__main__":
    main()
