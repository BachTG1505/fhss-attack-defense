"""
Task 2: TRICH XUAT BASELINE - audio sach
Tinh BER thuc te dung QIM extract.
"""
import numpy as np
from scipy.io import wavfile
from dwt_helper import haar_dwt_multilevel, LEVEL
from embed_message import DELTA, K_REPEAT, MESSAGE, text_to_bits, qim_extract_value, HOPPING_SEED


def extract_bits_from_audio(audio, n_bits_total):
    if audio.ndim > 1:
        audio = audio[:, 0]
    coeffs = haar_dwt_multilevel(audio.astype(np.float64), level=LEVEL)
    cD1 = coeffs[-1]

    np.random.seed(HOPPING_SEED)
    hopping = np.random.choice([-1, 1], size=n_bits_total)

    extracted = []
    n = min(n_bits_total, len(cD1))
    for i in range(n):
        bit = qim_extract_value(cD1[i], DELTA, hopping[i])
        extracted.append(bit)
    return extracted


def majority_vote_decode(bits, k):
    if k == 1:
        return bits
    decoded = []
    for i in range(0, len(bits), k):
        chunk = bits[i:i + k]
        if len(chunk) < k:
            break
        decoded.append(1 if sum(chunk) > k / 2 else 0)
    return decoded


def compute_ber(original, recovered):
    n = min(len(original), len(recovered))
    if n == 0:
        return 0.0
    errors = sum(1 for a, b in zip(original[:n], recovered[:n]) if a != b)
    return 100.0 * errors / n


def main():
    fs, stego = wavfile.read('stego_audio.wav')
    if stego.ndim > 1:
        stego = stego[:, 0]

    original_bits = text_to_bits(MESSAGE)
    n_encoded = len(original_bits) * K_REPEAT

    raw = extract_bits_from_audio(stego, n_encoded)
    decoded = majority_vote_decode(raw, K_REPEAT)
    ber = compute_ber(original_bits, decoded)

    print(f"[+] Baseline (audio sach):")
    print(f"    DELTA = {DELTA}, K_REPEAT = {K_REPEAT}")
    print(f"    BER = {ber:.2f}%")

    with open('baseline_report.txt', 'w') as f:
        f.write(f"Baseline BER = {ber:.2f}%\n")


if __name__ == "__main__":
    main()
