"""
Task 6: TAN CONG MP3 COMPRESSION
Nen audio thanh MP3 voi 3 bitrate khac nhau bang ffmpeg, do BER moi muc.
"""
import os
import subprocess
import numpy as np
from scipy.io import wavfile
from embed_message import DELTA, K_REPEAT, MESSAGE, text_to_bits
from extract_baseline import extract_bits_from_audio, majority_vote_decode, compute_ber

BITRATES = [128, 64, 32]


def mp3_round_trip(input_wav, bitrate):
    mp3_file = f"/tmp/stego_{bitrate}.mp3"
    out_wav = f"/tmp/stego_{bitrate}.wav"
    subprocess.run(
        ['ffmpeg', '-y', '-loglevel', 'quiet',
         '-i', input_wav, '-b:a', f'{bitrate}k', mp3_file],
        check=True
    )
    subprocess.run(
        ['ffmpeg', '-y', '-loglevel', 'quiet',
         '-i', mp3_file, out_wav],
        check=True
    )
    fs, audio = wavfile.read(out_wav)
    if audio.ndim > 1:
        audio = audio[:, 0]
    return fs, audio


def main():
    if not os.path.exists('stego_audio.wav'):
        print("[!] Khong tim thay stego_audio.wav. Chay embed_message.py truoc.")
        return

    original_bits = text_to_bits(MESSAGE)
    n_encoded = len(original_bits) * K_REPEAT

    results = []
    print("=" * 50)
    print("TASK 6: MP3 COMPRESSION ATTACK")
    print("=" * 50)
    print(f"Config: DELTA = {DELTA}, K_REPEAT = {K_REPEAT}\n")
    print(f"{'Bitrate':>10} | {'BER':>8} | {'Status':<20}")
    print("-" * 50)

    for bitrate in BITRATES:
        try:
            _, mp3_audio = mp3_round_trip('stego_audio.wav', bitrate)
        except subprocess.CalledProcessError as e:
            print(f"[!] ffmpeg loi tai bitrate {bitrate}: {e}")
            continue

        raw = extract_bits_from_audio(mp3_audio, n_encoded)
        decoded = majority_vote_decode(raw, K_REPEAT)
        ber = compute_ber(original_bits, decoded)

        status = "ATTACK SUCCESS" if ber >= 20 else "PARTIAL"
        results.append((bitrate, ber, status))
        print(f"{bitrate:>7} kbps | {ber:>7.2f}% | {status:<20}")

    with open('mp3_report.txt', 'w') as f:
        f.write("MP3 Compression BER Analysis\n")
        f.write("=" * 50 + "\n")
        f.write(f"Config: DELTA = {DELTA}, K_REPEAT = {K_REPEAT}\n\n")
        f.write(f"{'Bitrate':>10} | {'BER':>8} | {'Status':<20}\n")
        f.write("-" * 50 + "\n")
        for bitrate, ber, status in results:
            f.write(f"{bitrate:>7} kbps | {ber:>7.2f}% | {status:<20}\n")

    print(f"\n[+] Hoan thanh 3 muc bitrate. Bao cao: mp3_report.txt")


if __name__ == "__main__":
    main()
