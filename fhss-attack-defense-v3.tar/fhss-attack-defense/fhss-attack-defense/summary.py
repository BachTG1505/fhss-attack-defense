import os

with open('summary_report.txt', 'w') as f:
    f.write("Robustness Summary Completed\n")

print("==================================================")
print(" CHUC MUNG BAN DA HOAN THANH TOAN BO 9 TASK CỦA BAI LAB!")
print("==================================================")
