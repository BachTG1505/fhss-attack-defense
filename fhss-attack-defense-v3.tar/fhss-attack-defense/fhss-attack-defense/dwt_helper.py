"""
DWT Haar multi-level - Tu cai dat tu cong thuc
Khong dung thu vien pywt
"""
import numpy as np

LEVEL = 5

def haar_dwt_multilevel(signal, level=LEVEL):
    """
    DWT Haar phan tach 'level' lan.
    Tra ve list: [cA5, cD5, cD4, cD3, cD2, cD1]
    cA5: he so xap xi cap 5 (low-pass nhieu lan)
    cD1..cD5: he so chi tiet tu cap 1 den cap 5
    """
    coeffs = []
    current = signal.astype(np.float64)
    for _ in range(level):
        if len(current) % 2 != 0:
            current = np.append(current, current[-1])
        cA = (current[0::2] + current[1::2]) / np.sqrt(2)
        cD = (current[0::2] - current[1::2]) / np.sqrt(2)
        coeffs.append(cD)
        current = cA
    coeffs.append(current)
    return coeffs[::-1]


def haar_idwt_multilevel(coeffs):
    """
    Khoi phuc tin hieu tu list [cA5, cD5, cD4, cD3, cD2, cD1]
    """
    current = coeffs[0]
    for cD in coeffs[1:]:
        n = min(len(current), len(cD))
        current = current[:n]
        cD = cD[:n]
        reconstructed = np.zeros(2 * n)
        reconstructed[0::2] = (current + cD) / np.sqrt(2)
        reconstructed[1::2] = (current - cD) / np.sqrt(2)
        current = reconstructed
    return current
