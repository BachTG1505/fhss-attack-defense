"""
Task 1: NHUNG TIN BANG DWT-FHSS-QIM (Haar 5 level)
Su dung QIM (Quantization Index Modulation).

==================================================================
TODO CUA SINH VIEN (Task 7):
Tim DELTA va K_REPEAT thoa man dong thoi:
  - PSNR >= 40 dB
  - BER sau tan cong sigma=100 <= 5%
Goi y: thu DELTA = 500-2000, K_REPEAT = 3 hoac 5
==================================================================
"""
import os
import numpy as np
from scipy.io import wavfile
from dwt_helper import haar_dwt_multilevel, haar_idwt_multilevel, LEVEL

# ===========================================================
# TODO: Sinh vien chinh 2 tham so
DELTA = 20.0      # Mac dinh thap -> de bi nhieu pha
K_REPEAT = 1      # Mac dinh khong co Repetition Code
# Khoang toi uu: DELTA in [500, 2000], K_REPEAT in [3, 5]
# ===========================================================

MESSAGE = "HELLO PTIT!"
HOPPING_SEED = 42


def text_to_bits(text):
    bits = []
    for char in text:
        bits.extend([int(b) for b in format(ord(char), '08b')])
    return bits


def qim_embed_value(val, bit, delta, hop):
    """QIM voi hopping: bit=0 -> luong tu ve k*delta; bit=1 -> k*delta + delta/2"""
    actual_bit = bit if hop > 0 else (1 - bit)
    offset = 0.0 if actual_bit == 0 else delta / 2
    return round((val - offset) / delta) * delta + offset


def qim_extract_value(val, delta, hop):
    """Tach bit tu QIM: do offset cua val so voi luoi delta"""
    m = val % delta
    if m < 0:
        m += delta
    d0 = min(m, delta - m)
    d1 = abs(m - delta / 2)
    raw_bit = 0 if d0 < d1 else 1
    return raw_bit if hop > 0 else (1 - raw_bit)


def embed():
    if not os.path.exists('original_audio.wav'):
        fs_dummy = 44100
        t = np.linspace(0, 5, 5 * fs_dummy, endpoint=False)
        dummy = (np.sin(2 * np.pi * 440 * t) + np.sin(2 * np.pi * 880 * t)) * 8000
        wavfile.write('original_audio.wav', fs_dummy, dummy.astype(np.int16))

    fs, audio = wavfile.read('original_audio.wav')
    if audio.ndim > 1:
        audio = audio[:, 0]
    audio = audio.astype(np.float64)

    raw_bits = text_to_bits(MESSAGE)
    encoded_bits = []
    for b in raw_bits:
        encoded_bits.extend([b] * K_REPEAT)

    np.random.seed(HOPPING_SEED)
    hopping = np.random.choice([-1, 1], size=len(encoded_bits))

    coeffs = haar_dwt_multilevel(audio, level=LEVEL)
    cD1 = coeffs[-1].copy()
    n_embed = min(len(encoded_bits), len(cD1))

    for i in range(n_embed):
        cD1[i] = qim_embed_value(cD1[i], encoded_bits[i], DELTA, hopping[i])

    coeffs[-1] = cD1
    stego = haar_idwt_multilevel(coeffs)
    stego = stego[:len(audio)]
    stego_int = np.clip(stego, -32768, 32767).astype(np.int16)
    wavfile.write('stego_audio.wav', fs, stego_int)

    mse = np.mean((audio - stego) ** 2)
    psnr = 10 * np.log10((32767.0 ** 2) / mse) if mse > 0 else 100.0

    print(f"[*] Ket qua nhung:")
    print(f"    Thong diep: '{MESSAGE}' ({len(raw_bits)} bit goc)")
    print(f"    DELTA = {DELTA}, K_REPEAT = {K_REPEAT}")
    print(f"    PSNR = {psnr:.2f} dB")

    with open('psnr_check.txt', 'w') as f:
        f.write("PASSED" if psnr >= 40.0 else "FAILED")

    if K_REPEAT == 1:
        with open('embed_report.txt', 'w') as f:
            f.write("Baseline embedding successful\n")


if __name__ == "__main__":
    embed()
