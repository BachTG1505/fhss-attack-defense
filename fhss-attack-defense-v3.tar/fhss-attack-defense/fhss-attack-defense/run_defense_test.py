"""
Task 8: KIEM TRA PHONG THU
Verify dong thoi:
  1. PSNR >= 40 dB
  2. BER sau tan cong sigma=100 <= 5%
  3. Co 2 file session spectrogram before/after
"""
import os
import numpy as np
from scipy.io import wavfile
import embed_message
from embed_message import DELTA, K_REPEAT, MESSAGE, text_to_bits
from extract_baseline import extract_bits_from_audio, majority_vote_decode, compute_ber


def real_ber_after_attack():
    fs, stego = wavfile.read('stego_audio.wav')
    if stego.ndim > 1:
        stego = stego[:, 0]
    stego = stego.astype(np.float64)

    np.random.seed(123)
    noise = np.random.normal(0, 100, stego.shape)
    attacked = np.clip(stego + noise, -32768, 32767).astype(np.int16)

    original_bits = text_to_bits(MESSAGE)
    n_encoded = len(original_bits) * K_REPEAT
    raw = extract_bits_from_audio(attacked, n_encoded)
    decoded = majority_vote_decode(raw, K_REPEAT)
    return compute_ber(original_bits, decoded)


def main():
    psnr_passed = False
    if os.path.exists('psnr_check.txt'):
        with open('psnr_check.txt') as f:
            if "PASSED" in f.read():
                psnr_passed = True

    real_ber = real_ber_after_attack()
    ber_passed = real_ber <= 5.0
    param_ok = (K_REPEAT >= 3) and (500.0 <= DELTA <= 2000.0)

    task3_ok = os.path.exists('before_attack.sv') and os.path.getsize('before_attack.sv') > 100
    task5_ok = os.path.exists('after_attack.sv') and os.path.getsize('after_attack.sv') > 100

    print("=" * 50)
    print("TASK 8: VERIFY DEFENSE")
    print("=" * 50)
    print(f"  Tham so: DELTA = {DELTA}, K_REPEAT = {K_REPEAT}")
    print(f"  PSNR check (>=40 dB):           {'PASS' if psnr_passed else 'FAIL'}")
    print(f"  BER sau attack sigma=100:       {real_ber:.2f}% ({'PASS' if ber_passed else 'FAIL'})")
    print(f"  Parameter range (DELTA 500-2000, K_REPEAT>=3): {'PASS' if param_ok else 'FAIL'}")
    print(f"  before_attack.sv:               {'PASS' if task3_ok else 'FAIL'}")
    print(f"  after_attack.sv:                {'PASS' if task5_ok else 'FAIL'}")

    with open('defense_report.txt', 'w') as f:
        f.write("Defense Verification Report\n")
        f.write("=" * 40 + "\n")
        f.write(f"DELTA = {DELTA}, K_REPEAT = {K_REPEAT}\n")
        f.write(f"PSNR check: {'PASSED' if psnr_passed else 'FAILED'}\n")
        f.write(f"Real BER (sigma=100): {real_ber:.2f}%\n")
        f.write(f"Param range OK: {param_ok}\n\n")

        if psnr_passed and ber_passed and param_ok:
            f.write("Defense active. BER reduced\n")
            print("\n[+] CHUC MUNG: Cau hinh DAT yeu cau toi uu!")
        else:
            f.write("Defense FAILED constraints.\n")
            print("\n[!] CHUA DAT: Hay tinh chinh tham so.")
            if not psnr_passed:
                print("   -> DELTA qua lon, PSNR < 40dB. Giam DELTA xuong.")
            if not ber_passed:
                print(f"   -> BER {real_ber:.2f}% > 5%. Tang K_REPEAT hoac DELTA.")
            if not param_ok:
                print("   -> Tham so ngoai khoang [500,2000] cho DELTA hoac K_REPEAT<3.")

        if task3_ok:
            f.write("Before Attack Spectrum Verified\n")
        if task5_ok:
            f.write("After Attack Spectrum Verified\n")

    if not task3_ok:
        print("[!] Canh bao: Chua co before_attack.sv (Task 3 - mo sonic-visualiser)")
    if not task5_ok:
        print("[!] Canh bao: Chua co after_attack.sv (Task 5 - mo sonic-visualiser)")


if __name__ == "__main__":
    main()
