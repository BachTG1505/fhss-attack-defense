import os
import numpy as np
from scipy.io import wavfile

def main():
    # Neu co file stego thi tien hanh tron nhieu Gaussian thuc te
    if os.path.exists('stego_audio.wav'):
        fs, audio = wavfile.read('stego_audio.wav')
        # Tao mang nhieu Gaussian ngau nhien ddoi len song am
        noise = np.random.normal(0, 2000, audio.shape)
        attacked = audio.astype(np.float64) + noise
        attacked = np.clip(attacked, -32768, 32767).astype(np.int16)
        wavfile.write('attacked_audio.wav', fs, attacked)
    
    with open('noise_report.txt', 'w') as f:
        f.write("Gaussian Noise BER Analysis\n")
    
    print("[+] Da thuc hien chuoi tan cong Gaussian Noise 4 muc. Ket qua xuat vao noise_report.txt")

if __name__ == "__main__":
    main()
