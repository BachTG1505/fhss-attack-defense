import os
import embed_message

# 1. Kiem tra PSNR tu buoc nhung cua sinh vien
psnr_passed = False
if os.path.exists('psnr_check.txt'):
    with open('psnr_check.txt', 'r') as f:
        if "PASSED" in f.read():
            psnr_passed = True

# 2. Kiem tra BER dat yeu cau (K>=3 va ALPHA dung trong khoang toi uu)
ber_passed = False
if embed_message.K_REPEAT >= 3 and 40.0 <= embed_message.ALPHA <= 100.0:
    ber_passed = True

# 3. Kiem tra ngam xem 2 file session nhi phan cua Task 3 va 5 co ton tai khong
task3_passed = os.path.exists('before_attack.sv') and os.path.getsize('before_attack.sv') > 100
task5_passed = os.path.exists('after_attack.sv') and os.path.getsize('after_attack.sv') > 100

# Ghi tat ca ket qua vao mot file bao cao duy nhat de Labtainer quet
with open('defense_report.txt', 'w') as f:
    if psnr_passed and ber_passed:
        f.write("Defense active. BER reduced\n")
        print("[+] CHUC MUNG: Cau hinh thoa man rang buoc toi uu (PSNR >= 40dB va BER <= 5%)!")
    else:
        f.write("Defense active. FAILED constraints.\n")
        print("[!] THAT BAI: Tham so cau hinh chua toi uu.")
        if not psnr_passed: print("   -> Loi: Am thanh bi meo re do ALPHA qua lon, PSNR qua thap (< 40dB).")
        if not ber_passed: print("   -> Loi: Ty le loi bit (BER) sau tan cong qua cao (> 5%). Hay tang K_REPEAT hoac ALPHA.")

    if task3_passed:
        f.write("Before Attack Spectrum Verified\n")
    if task5_passed:
        f.write("After Attack Spectrum Verified\n")

# Canh bao truc quan cho sinh vien neu quen khong luu file tren GUI
if not task3_passed:
    print("[!] Canh bao: Ban chua mo Sonic Visualiser de luu file 'before_attack' tai Task 3!")
if not task5_passed:
    print("[!] Canh bao: Ban chua mo Sonic Visualiser de luu file 'after_attack' tai Task 5!")
