import numpy as np

def haar_dwt_1d(signal):
    n = len(signal)
    if n % 2 != 0:
        signal = np.append(signal, signal[-1])
        n += 1
    cA = (signal[0::2] + signal[1::2]) / np.sqrt(2)
    cD = (signal[0::2] - signal[1::2]) / np.sqrt(2)
    return cA, cD

def haar_idwt_1d(cA, cD):
    n = len(cA) * 2
    reconstructed = np.zeros(n)
    reconstructed[0::2] = (cA + cD) / np.sqrt(2)
    reconstructed[1::2] = (cA - cD) / np.sqrt(2)
    return reconstructed
