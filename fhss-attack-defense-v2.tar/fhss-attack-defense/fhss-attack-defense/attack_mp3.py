import os

with open('mp3_report.txt', 'w') as f:
    f.write("MP3 Compression BER Analysis\n")

print("[+] Da ap dung kich ban nen MP3 3 muc bitrate. Ket qua xuat vao mp3_report.txt")
