import os
import numpy as np
from scipy.io import wavfile
from dwt_helper import haar_dwt_1d, haar_idwt_1d

# =======================================================================
# TODO BAI TOAN TOI UU: Sinh vien tu thay doi 2 tham so nay de he thong
# thoa man dong thoi: PSNR >= 40 dB VA BER sau tan cong <= 5%
ALPHA = 10.0      # Bien do nhung mac dinh (Qua thap, de bi nhieu pha huy)
K_REPEAT = 1      # Ma lap mac dinh (Khong co kha nang sua loi)
# =======================================================================

def text_to_bits(text):
    bits = []
    for char in text:
        bits.extend([int(b) for b in format(ord(char), '08b')])
    return bits

def embed():
    if not os.path.exists('original_audio.wav'):
        fs_dummy = 44100
        t = np.linspace(0, 5, 5 * fs_dummy, endpoint=False)
        dummy_audio = (np.sin(2 * np.pi * 440 * t) + np.sin(2 * np.pi * 880 * t)) * 8000
        wavfile.write('original_audio.wav', fs_dummy, dummy_audio.astype(np.int16))

    fs, audio = wavfile.read('original_audio.wav')
    if audio.ndim > 1: audio = audio[:, 0]
    
    raw_bits = text_to_bits("HELLO PTIT!")
    encoded_bits = []
    for b in raw_bits:
        encoded_bits.extend([b] * K_REPEAT)
        
    np.random.seed(42)
    hopping_sequence = np.random.choice([-1, 1], size=len(encoded_bits))
    
    cA, cD = haar_dwt_1d(audio)
    for i in range(min(len(encoded_bits), len(cD))):
        bit_val = 1 if encoded_bits[i] == 1 else -1
        cD[i] += ALPHA * bit_val * hopping_sequence[i]
        
    stego_audio = haar_idwt_1d(cA, cD)
    stego_audio = np.clip(stego_audio, -32768, 32767).astype(np.int16)
    wavfile.write('stego_audio.wav', fs, stego_audio)
    
    # Tinh toan PSNR thuc te dua tren tham so ALPHA sinh vien nhap
    mse = np.mean((audio.astype(np.float64) - stego_audio.astype(np.float64)) ** 2)
    max_pixel = 32767.0
    psnr = 10 * np.log10((max_pixel ** 2) / mse) if mse > 0 else 100
    
    print(f"[*] Ket qua nhung: PSNR = {psnr:.2f} dB | K_REPEAT = {K_REPEAT} | ALPHA = {ALPHA}")
    
    with open('psnr_check.txt', 'w') as f:
        if psnr >= 40.0:
            f.write("PASSED")
        else:
            f.write("FAILED")

    if K_REPEAT == 1:
        with open('embed_report.txt', 'w') as f:
            f.write("Baseline embedding successful\n")

if __name__ == "__main__":
    embed()
