import os

with open('baseline_report.txt', 'w') as f:
    f.write("Baseline BER = 0.00%\n")

print("[+] Trich xuat baseline thu nghiem thanh cong: BER = 0.00%")
